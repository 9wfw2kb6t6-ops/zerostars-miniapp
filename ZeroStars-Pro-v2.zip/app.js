import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js';
import { getFirestore, doc, setDoc, getDoc, collection, getDocs } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';

const firebaseConfig = {
 apiKey:'AIzaSyBfOoEJ0BxhhjkXdL4ae-z5dSrflRG6GQc',
 authDomain:'zerostars-97e21.firebaseapp.com',
 projectId:'zerostars-97e21',
 storageBucket:'zerostars-97e21.firebasestorage.app',
 messagingSenderId:'617216289630',
 appId:'1:617216289630:web:d5d44b81af4ed85e113dcf'
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

let user = localStorage.getItem('zs_user') || prompt('Username') || 'Player';
localStorage.setItem('zs_user', user);

let coins=0,xp=0,level=1,energy=100,miners=0;

async function save(){
 await setDoc(doc(db,'players',user),{user,coins,xp,level,miners});
}

async function load(){
 const s=await getDoc(doc(db,'players',user));
 if(s.exists()) Object.assign(window,s.data());
 update();
}

function update(){
 coinsEl.textContent=coins;
 levelEl.textContent=level;
 xpEl.textContent=xp;
 minersEl.textContent=miners;
 energyText.textContent=`${energy}/100 Energy`;
 energyFill.style.width=(energy)+'%';
}

mineBtn.onclick=()=>{
 if(energy<=0) return;
 coins++; xp++; energy--;
 if(xp>=100){xp=0;level++;}
 update(); save();
};

upgradeBtn.onclick=()=>{
 if(coins<50) return;
 coins-=50; level++;
 update(); save();
};

minerBtn.onclick=()=>{
 if(coins<100) return;
 coins-=100; miners++;
 update(); save();
};

dailyBtn.onclick=()=>{
 const d=new Date().toDateString();
 if(localStorage.getItem('daily')===d) return alert('Already claimed');
 localStorage.setItem('daily',d);
 coins+=500;
 update(); save();
};

setInterval(()=>{ if(energy<100){energy++; update();}},1000);
setInterval(()=>{ if(miners>0){coins+=miners; update(); save();}},1000);

async function board(){
 const q=await getDocs(collection(db,'players'));
 let arr=[]; q.forEach(x=>arr.push(x.data()));
 arr.sort((a,b)=>b.coins-a.coins);
 leaderboard.innerHTML=arr.slice(0,10).map((p,i)=>`${i+1}. ${p.user} - ${p.coins}`).join('<br>');
}
setInterval(board,5000);

load(); board();
